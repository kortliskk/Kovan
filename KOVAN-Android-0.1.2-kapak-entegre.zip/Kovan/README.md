# KOVAN 🐝

**KOVAN**, gizlilik odaklı ve Bluetooth'a bağımlı olmayan bir Android mesajlaşma projesidir. İlk hedef, aynı yerel Wi-Fi ağı üzerindeki cihazların bir oda parolasıyla sohbet edebilmesidir. İnternet üzerinden mesajlaşma sonraki aşamalarda eklenecektir.

| Proje bilgisi | Değer |
|---|---|
| Proje sahibi | **Kortliskk** |
| İletişim | kortliskk@gmail.com |
| Kaynak deposu | https://github.com/kortliskk/Kovan |
| Platform | Android |
| İlk sürüm | 0.1.0 |

## Bu sürümde bulunanlar

- Modern, koyu temalı Android arayüzü.
- Oda adı, görünen ad ve ortak oda parolasıyla yerel sohbet odası.
- Aynı Wi-Fi/LAN üzerindeki cihazlara UDP broadcast ile mesaj gönderme ve oda katılımcılarını algılama.
- Mesaj paketlerinde AES-GCM şifreleme; oda anahtarı PBKDF2-HMAC-SHA256 ile türetilir.
- Sohbet geçmişinin cihazda yerel SQLite veritabanına kaydedilmesi.
- Oda parolasının uygulama tercihlerine kaydedilmemesi.
- Android 8.0 ve üzeri için başlangıç düzeyinde destek (API 26+).
- GitHub Actions üzerinden debug APK derleme iş akışı.

## İlk deneme nasıl yapılır?

1. KOVAN'ı iki Android cihaza yükle.
2. İki cihazı da aynı Wi-Fi ağına bağla. Mobil veri tek başına yeterli değildir.
3. Her iki cihazda aynı oda adını ve aynı, en az 12 karakterli oda parolasını gir. Görünen adlar farklı olabilir.
4. Bir cihazdan mesaj gönder; diğer cihazda mesajın görünmesini kontrol et.

**Not:** Bazı modemler bağlı cihazların birbirleriyle konuşmasını engelleyen "AP/client isolation" özelliğini kullanabilir. Böyle bir ağda KOVAN cihazları bulamayabilir. Misafir Wi-Fi ağlarında da cihazlar arası iletişim kapalı olabilir.

## Önemli sınırlar

Bu, gerçek cihazlarda denenmesi gereken ilk MVP sürümüdür; henüz üretim seviyesinde bir mesajlaşma ürünü değildir.

- İlk sürüm yalnızca aynı yerel ağdaki cihazlar arasında çalışır. Farklı şehirlerdeki internet kullanıcılarını birbirine bağlayan bir sunucu/relay henüz yoktur.
- Uygulama açık ve ön plandayken mesaj alır. Uygulama kapalıyken veya işletim sistemi tarafından durdurulmuşken sürekli teslimat garanti edilmez.
- Mesajlar güvenilir olmayan UDP ağı üzerinden gönderildiğinden kayıp veya yinelenme olasılığı vardır. Bu sürümde çevrimdışı teslim kuyruğu ve teslim edildi onayı yoktur.
- AES-GCM oda parolasıyla paylaşılan grup anahtarı kullanır. Bu, bağımsız denetimden geçmiş Signal Protocol benzeri kimlik tabanlı uçtan uca şifreleme değildir. Oda parolası zayıfsa veya dışarı sızarsa oda trafiği korunmuş sayılmaz.
- Mesaj geçmişi cihazın yerel uygulama veritabanında tutulur. Veritabanı ayrıca uygulama düzeyinde şifrelenmez.
- Dosya, fotoğraf, sesli mesaj, arama, davet bağlantısı ve çoklu oda yönetimi henüz eklenmedi.

Oda parolasını yalnızca güvendiğin kişilerle güvenli bir kanaldan paylaş. Gerçek hassas bilgiler için bu deneysel sürüme güvenme.

## Teknoloji

- Kotlin
- Jetpack Compose ve Material 3
- Android SDK 36, minimum SDK 26
- UDP broadcast (yerel ağ aktarımı)
- AES-GCM ve PBKDF2-HMAC-SHA256
- SQLite (yerel sohbet geçmişi)
- GitHub Actions

## Yol haritası

- [x] Android uygulama iskeleti ve temel arayüz
- [x] Yerel ağ üzerinden şifrelenmiş kısa mesaj gönderme/alma prototipi
- [x] Yerel sohbet geçmişi
- [ ] Gerçek cihazlarda çoklu üretici/Wi-Fi ağı testleri
- [ ] Wi-Fi Direct ile yönlendirici olmadan cihazdan cihaza bağlantı
- [ ] Daha güvenilir keşif, teslim onayı ve çevrimdışı mesaj kuyruğu
- [ ] Kimlik doğrulamalı, denetlenmiş uçtan uca şifreleme tasarımı
- [ ] Ücretsiz/öz barındırılabilir internet aktarım katmanı
- [ ] Grup sohbetleri, dosya ve sesli mesajlar
- [ ] Arka plan bildirimleri ve pil kullanımı testleri

Gerçek cihazlarda deneme adımları için [docs/TESTING.md](docs/TESTING.md) dosyasına bak.

## Derleme

Projeyi Android Studio'da açıp Gradle senkronizasyonunu çalıştır. Komut satırından debug APK üretmek için:

```bash
./gradlew assembleDebug
```

Windows:

```bat
gradlew.bat assembleDebug
```

GitHub Actions başarılı olduğunda `KOVAN-debug-apk` adlı Actions artifact'i içinde debug APK bulunur. Bu debug APK test içindir; mağaza yayınına hazır imzalı release değildir.

## Katkı ve hata bildirimi

Hata bildirirken Android sürümünü, cihaz modelini, iki cihazın aynı Wi-Fi'de olup olmadığını ve mümkünse hatanın tekrar adımlarını ekle. Parola, özel mesaj veya kişisel bilgi paylaşma.

## Telif hakkı

**Copyright (c) 2026 Kortliskk. All rights reserved.**

Bu depodaki özgün kaynak kodu, tasarım, dokümantasyon ve görseller, aksi açıkça belirtilmedikçe Kortliskk'e aittir. Önceden yazılı izin olmadan kopyalanamaz, değiştirilemez, yeniden yayımlanamaz, dağıtılamaz veya ticari olarak kullanılamaz. Üçüncü taraf bileşenler kendi lisanslarına tabidir. GitHub'ın hizmet şartları ve yürürlükteki hukuk saklıdır.

İzin ve iş birliği talepleri: **kortliskk@gmail.com**
