# KOVAN 0.1.0 — test checklist

Use two real Android devices. Emulator-to-emulator broadcast can behave differently from real Wi-Fi hardware.

1. Install the same debug APK on both devices.
2. Connect both devices to the same non-guest Wi-Fi network.
3. Open KOVAN on both devices.
4. Enter different display names, but exactly the same room name and password (at least 12 characters).
5. Wait for the peer count to update, then send a short test message in both directions.
6. Close and reopen the app, join the same room again, and check that the local message history remains visible.
7. Repeat with the wrong room password; messages from the other room key should not decrypt.

If devices do not see each other, check whether the router has AP/client isolation enabled. Guest networks commonly block device-to-device traffic. Keep both devices on the same local subnet and ensure Wi-Fi is active.

## Known limits

- UDP does not guarantee delivery. A sent message is not proof that the other device received it.
- The peer count is based on periodic heartbeat packets and may take up to about 22 seconds to expire a disconnected peer.
- The app currently receives messages only while it is running in the foreground.
- Testing on a physical device is still required before calling this release stable.
