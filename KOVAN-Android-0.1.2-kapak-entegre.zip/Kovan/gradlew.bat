@echo off
setlocal
set GRADLE_VERSION=8.13
set GRADLE_CACHE=%USERPROFILE%\.gradle\kovan-wrapper
set GRADLE_HOME=%GRADLE_CACHE%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%GRADLE_CACHE%" mkdir "%GRADLE_CACHE%"
  set ZIP=%GRADLE_CACHE%\gradle-%GRADLE_VERSION%-bin.zip
  if not exist "%ZIP%" powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if exist "%GRADLE_CACHE%\unpack" rmdir /s /q "%GRADLE_CACHE%\unpack"
  powershell -NoProfile -Command "Expand-Archive -Force '%ZIP%' '%GRADLE_CACHE%\unpack'"
  move "%GRADLE_CACHE%\unpack\gradle-%GRADLE_VERSION%" "%GRADLE_HOME%"
  rmdir "%GRADLE_CACHE%\unpack"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
