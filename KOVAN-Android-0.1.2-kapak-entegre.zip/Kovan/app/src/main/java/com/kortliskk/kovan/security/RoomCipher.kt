package com.kortliskk.kovan.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Shared-room encryption for this early prototype.
 * Every participant must enter the same room password.
 * This is not a replacement for audited identity-based end-to-end encryption.
 */
class RoomCipher(roomName: String, password: String) {
    private val key: SecretKeySpec
    private val random = SecureRandom()

    init {
        require(password.length >= MIN_PASSWORD_LENGTH) {
            "Oda parolası en az $MIN_PASSWORD_LENGTH karakter olmalı."
        }
        val normalizedRoom = roomName.trim().lowercase(Locale.ROOT)
        val salt = sha256("KOVAN-ROOM|$normalizedRoom".toByteArray(Charsets.UTF_8))
        val passwordChars = password.toCharArray()
        val spec = PBEKeySpec(passwordChars, salt, PBKDF2_ITERATIONS, 256)
        try {
            val rawKey = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
            key = SecretKeySpec(rawKey, "AES")
        } finally {
            spec.clearPassword()
            passwordChars.fill('\u0000')
        }
    }

    fun encrypt(plainText: String, associatedData: String): EncryptedPayload {
        val nonce = ByteArray(GCM_NONCE_BYTES).also(random::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonce))
        cipher.updateAAD(associatedData.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        return EncryptedPayload(
            nonce = Base64.encodeToString(nonce, Base64.NO_WRAP),
            ciphertext = Base64.encodeToString(encrypted, Base64.NO_WRAP)
        )
    }

    fun decrypt(nonceBase64: String, ciphertextBase64: String, associatedData: String): String {
        val nonce = Base64.decode(nonceBase64, Base64.NO_WRAP)
        val encrypted = Base64.decode(ciphertextBase64, Base64.NO_WRAP)
        require(nonce.size == GCM_NONCE_BYTES) { "Geçersiz mesaj paketi." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, nonce))
        cipher.updateAAD(associatedData.toByteArray(Charsets.UTF_8))
        return cipher.doFinal(encrypted).toString(Charsets.UTF_8)
    }

    data class EncryptedPayload(val nonce: String, val ciphertext: String)

    companion object {
        const val MIN_PASSWORD_LENGTH = 12
        private const val PBKDF2_ITERATIONS = 210_000
        private const val GCM_NONCE_BYTES = 12
        private const val GCM_TAG_BITS = 128

        fun roomHash(roomName: String): String {
            val normalized = roomName.trim().lowercase(Locale.ROOT)
            return sha256("KOVAN-ROOM-ID|$normalized".toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
        }

        private fun sha256(input: ByteArray): ByteArray =
            MessageDigest.getInstance("SHA-256").digest(input)
    }
}
