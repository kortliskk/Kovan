package com.kortliskk.kovan.model

data class ChatMessage(
    val id: String,
    val roomId: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val sentAt: Long,
    val isMine: Boolean
)
