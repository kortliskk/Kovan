package com.kortliskk.kovan

import android.os.Bundle
import android.net.wifi.WifiManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kortliskk.kovan.data.ChatDatabase
import com.kortliskk.kovan.model.ChatMessage
import com.kortliskk.kovan.network.LanChatEngine
import com.kortliskk.kovan.security.RoomCipher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF0B1420)
private val Panel = Color(0xFF142334)
private val PanelSoft = Color(0xFF1A2D40)
private val Mint = Color(0xFF39D7A5)
private val TextMain = Color(0xFFF1F6F8)
private val TextMuted = Color(0xFF9BAEBD)

class MainActivity : ComponentActivity() {

    private lateinit var database: ChatDatabase
    private lateinit var lanEngine: LanChatEngine
    private var multicastLock: WifiManager.MulticastLock? = null
    private val chatMessages = mutableStateListOf<ChatMessage>()

    private var isConnected by mutableStateOf(false)
    private var connectionStatus by mutableStateOf("Henüz bir odaya bağlanmadın")
    private var connectedPeers by mutableStateOf(0)
    private var activeRoomId by mutableStateOf("")
    private var activeRoomName by mutableStateOf("")

    private val preferences by lazy { getSharedPreferences("kovan_profile", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = ChatDatabase(applicationContext)
        val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        multicastLock = wifiManager.createMulticastLock("KOVAN-LAN").apply {
            setReferenceCounted(false)
        }
        lanEngine = LanChatEngine(object : LanChatEngine.Listener {
            override fun onMessage(message: ChatMessage) {
                runOnUiThread {
                    if (message.roomId == activeRoomId && chatMessages.none { it.id == message.id }) {
                        database.save(message)
                        chatMessages.add(message)
                    }
                }
            }

            override fun onStatus(message: String) {
                runOnUiThread { connectionStatus = message }
            }

            override fun onPeerCount(count: Int) {
                runOnUiThread { connectedPeers = count }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    connectionStatus = message
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        })

        window.statusBarColor = android.graphics.Color.rgb(11, 20, 32)
        window.navigationBarColor = android.graphics.Color.rgb(11, 20, 32)

        setContent {
            KovanTheme {
                KovanScreen(
                    messages = chatMessages,
                    connected = isConnected,
                    connectionStatus = connectionStatus,
                    peerCount = connectedPeers,
                    roomName = activeRoomName,
                    initialName = preferences.getString("display_name", "") ?: "",
                    initialRoom = preferences.getString("room_name", "Arkadaşlar") ?: "Arkadaşlar",
                    onJoinRoom = ::joinRoom,
                    onSendMessage = ::sendMessage,
                    onDisconnect = ::disconnectRoom
                )
            }
        }
    }

    private fun joinRoom(name: String, room: String, password: String): Boolean {
        val cleanName = name.trim()
        val cleanRoom = room.trim()
        if (cleanName.length !in 2..24) {
            Toast.makeText(this, "İsim 2–24 karakter olmalı.", Toast.LENGTH_SHORT).show()
            return false
        }
        if (cleanRoom.length !in 2..24) {
            Toast.makeText(this, "Oda adı 2–24 karakter olmalı.", Toast.LENGTH_SHORT).show()
            return false
        }
        if (password.length < RoomCipher.MIN_PASSWORD_LENGTH) {
            Toast.makeText(this, "Oda parolası en az 12 karakter olmalı.", Toast.LENGTH_SHORT).show()
            return false
        }

        return try {
            activeRoomName = cleanRoom
            activeRoomId = RoomCipher.roomHash(cleanRoom)
            multicastLock?.let { if (!it.isHeld) it.acquire() }
            lanEngine.start(cleanName, cleanRoom, password)
            preferences.edit()
                .putString("display_name", cleanName)
                .putString("room_name", cleanRoom)
                .apply()
            chatMessages.clear()
            chatMessages.addAll(database.load(activeRoomId))
            isConnected = true
            connectionStatus = "Yerel ağ dinleniyor"
            true
        } catch (error: Exception) {
            multicastLock?.let { if (it.isHeld) it.release() }
            isConnected = false
            connectionStatus = error.message ?: "Odaya bağlanılamadı"
            Toast.makeText(this, connectionStatus, Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun sendMessage(text: String) {
        if (!isConnected) return
        Thread({
            try {
                val message = lanEngine.sendMessage(text)
                runOnUiThread {
                    database.save(message)
                    if (chatMessages.none { it.id == message.id }) chatMessages.add(message)
                }
            } catch (error: Exception) {
                runOnUiThread {
                    connectionStatus = error.message ?: "Mesaj gönderilemedi"
                    Toast.makeText(this, connectionStatus, Toast.LENGTH_LONG).show()
                }
            }
        }, "KOVAN-LAN-Send").start()
    }

    private fun disconnectRoom() {
        lanEngine.stop()
        multicastLock?.let { if (it.isHeld) it.release() }
        isConnected = false
        connectedPeers = 0
        connectionStatus = "Bağlantı kapatıldı"
    }

    override fun onDestroy() {
        if (::lanEngine.isInitialized) lanEngine.stop()
        multicastLock?.let { if (it.isHeld) it.release() }
        if (::database.isInitialized) database.close()
        super.onDestroy()
    }
}

@Composable
private fun KovanTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Mint,
            onPrimary = Ink,
            secondary = Color(0xFF80E8C7),
            background = Ink,
            surface = Panel,
            onSurface = TextMain,
            onBackground = TextMain
        ),
        content = content
    )
}

@Composable
private fun KovanScreen(
    messages: List<ChatMessage>,
    connected: Boolean,
    connectionStatus: String,
    peerCount: Int,
    roomName: String,
    initialName: String,
    initialRoom: String,
    onJoinRoom: (String, String, String) -> Boolean,
    onSendMessage: (String) -> Unit,
    onDisconnect: () -> Unit
) {
    var showSetup by rememberSaveable { mutableStateOf(!connected) }
    var draft by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .imePadding()
                .padding(horizontal = 18.dp)
        ) {
            Header(
                connected = connected,
                onSettings = { showSetup = true },
                onDisconnect = onDisconnect
            )

            Spacer(Modifier.height(14.dp))
            ConnectionCard(
                connected = connected,
                status = connectionStatus,
                roomName = roomName,
                peerCount = peerCount
            )
            Spacer(Modifier.height(12.dp))

            if (connected) {
                if (messages.isEmpty()) {
                    EmptyChat(roomName = roomName, modifier = Modifier.weight(1f))
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                "ODA MESAJLARI",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.8.sp,
                                modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 3.dp)
                            )
                        }
                        items(messages, key = { it.id }) { message ->
                            MessageBubble(message)
                        }
                    }
                }
                Composer(
                    value = draft,
                    onValueChange = { draft = it.take(1_200) },
                    onSend = {
                        val clean = draft.trim()
                        if (clean.isNotEmpty()) {
                            onSendMessage(clean)
                            draft = ""
                        }
                    }
                )
                Spacer(Modifier.height(12.dp))
            } else {
                WelcomePanel(
                    onConnect = { showSetup = true },
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "KOVAN  •  ÖZEL ALANIN, KENDİ TOPLULUĞUN",
                    color = TextMuted,
                    fontSize = 9.sp,
                    letterSpacing = 1.2.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 18.dp)
                )
            }
        }

        if (showSetup) {
            RoomSetupDialog(
                initialName = initialName,
                initialRoom = if (connected) roomName else initialRoom,
                onDismiss = { showSetup = false },
                onConfirm = { name, room, password ->
                    if (onJoinRoom(name, room, password)) showSetup = false
                }
            )
        }
    }
}

@Composable
private fun Header(
    connected: Boolean,
    onSettings: () -> Unit,
    onDisconnect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 18.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(46.dp),
            shape = RoundedCornerShape(15.dp),
            color = Mint
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("K", color = Ink, fontSize = 27.sp, fontWeight = FontWeight.Black)
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("KOVAN", color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text("Yakınlarınla aynı alanda", color = TextMuted, fontSize = 11.sp)
        }
        if (connected) {
            TextButton(onClick = onDisconnect) {
                Text("Çıkış", color = Color(0xFFFFB3A8), fontSize = 12.sp)
            }
        }
        TextButton(onClick = onSettings) {
            Text("Ayarlar", color = Mint, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ConnectionCard(
    connected: Boolean,
    status: String,
    roomName: String,
    peerCount: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 15.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(if (connected) Mint else Color(0xFF81909B), CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (connected) "${roomName.ifBlank { "Yerel oda" }}  •  Yerel ağ" else "Çevrimdışı alan",
                    color = TextMain,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Text(status, color = TextMuted, fontSize = 10.sp, maxLines = 2)
            }
            if (connected) {
                Surface(color = PanelSoft, shape = RoundedCornerShape(30.dp)) {
                    Text(
                        "$peerCount cihaz",
                        color = Mint,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun WelcomePanel(onConnect: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.kovan_cover),
            contentDescription = "KOVAN kapak görseli",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(166.dp)
                .clip(RoundedCornerShape(30.dp))
        )
        Spacer(Modifier.height(18.dp))
        Text("Kendi odanı kur.", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(
            "Aynı Wi-Fi ağına bağlı arkadaşlarınla\nözel bir sohbet alanı aç.",
            color = TextMuted,
            fontSize = 13.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 9.dp, bottom = 23.dp)
        )
        Button(
            onClick = onConnect,
            colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth(0.82f).height(50.dp)
        ) {
            Text("Oda oluştur / Katıl", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(Modifier.height(22.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(15.dp)) {
                Text("Nasıl çalışır?", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "• İki cihaz da aynı Wi-Fi ağına bağlı olmalı.\n• Oda adı ve parola iki cihazda da aynı girilmeli.\n• Bluetooth veya ücretli sunucu kullanılmaz.",
                    color = TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 19.sp
                )
            }
        }
    }
}

@Composable
private fun EmptyChat(roomName: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("✦", color = Mint, fontSize = 34.sp)
        Spacer(Modifier.height(8.dp))
        Text("Oda hazır", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(
            "${roomName.ifBlank { "Bu oda" }} odasında henüz mesaj yok.\nArkadaşlarından aynı oda bilgileriyle katılmalarını iste.",
            color = TextMuted,
            fontSize = 12.sp,
            lineHeight = 19.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isMine) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.84f)
                .background(
                    color = if (message.isMine) Color(0xFF1D705D) else PanelSoft,
                    shape = RoundedCornerShape(
                        topStart = 17.dp,
                        topEnd = 17.dp,
                        bottomStart = if (message.isMine) 17.dp else 5.dp,
                        bottomEnd = if (message.isMine) 5.dp else 17.dp
                    )
                )
                .padding(horizontal = 13.dp, vertical = 10.dp)
        ) {
            if (!message.isMine) {
                Text(message.senderName, color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(3.dp))
            }
            Text(message.text, color = TextMain, fontSize = 14.sp, lineHeight = 20.sp)
            Text(
                formatTime(message.sentAt),
                color = Color(0xFFBDD5D0),
                fontSize = 9.sp,
                textAlign = TextAlign.End,
                modifier = Modifier.align(Alignment.End).padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun Composer(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Mesajını yaz...", color = TextMuted, fontSize = 13.sp) },
            shape = RoundedCornerShape(16.dp),
            maxLines = 4,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { onSend() })
        )
        Spacer(Modifier.width(9.dp))
        Button(
            onClick = onSend,
            enabled = value.trim().isNotEmpty(),
            modifier = Modifier.size(53.dp),
            shape = RoundedCornerShape(16.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Mint,
                contentColor = Ink,
                disabledContainerColor = PanelSoft,
                disabledContentColor = TextMuted
            )
        ) {
            Text("➤", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RoomSetupDialog(
    initialName: String,
    initialRoom: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var name by rememberSaveable { mutableStateOf(initialName) }
    var room by rememberSaveable { mutableStateOf(initialRoom.ifBlank { "Arkadaşlar" }) }
    var password by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        titleContentColor = TextMain,
        textContentColor = TextMuted,
        title = {
            Column {
                Text("Kovan odası", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Text("Arkadaşlarınla aynı bilgileri kullan.", color = TextMuted, fontSize = 11.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(24) },
                    label = { Text("Görünen ad") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it.take(24) },
                    label = { Text("Oda adı") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it.take(64) },
                    label = { Text("Ortak oda parolası") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    )
                )
                Text(
                    "Parola bu cihazda kaydedilmez. En az 12 karakter kullan ve yalnızca davet ettiğin kişilerle güvenli biçimde paylaş.",
                    color = TextMuted,
                    fontSize = 10.sp,
                    lineHeight = 15.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(name.trim(), room.trim(), password) },
                enabled = name.trim().length >= 2 && room.trim().length >= 2 && password.length >= RoomCipher.MIN_PASSWORD_LENGTH,
                colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink)
            ) {
                Text("Bağlan", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Vazgeç", color = TextMuted)
            }
        }
    )
}

private fun formatTime(timeMillis: Long): String =
    SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date(timeMillis))
