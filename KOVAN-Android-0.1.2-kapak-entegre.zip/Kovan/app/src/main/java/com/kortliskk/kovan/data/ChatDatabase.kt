package com.kortliskk.kovan.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.kortliskk.kovan.model.ChatMessage

class ChatDatabase(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE messages (
                id TEXT PRIMARY KEY NOT NULL,
                room_id TEXT NOT NULL,
                sender_id TEXT NOT NULL,
                sender_name TEXT NOT NULL,
                body TEXT NOT NULL,
                sent_at INTEGER NOT NULL,
                is_mine INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX index_messages_room_time ON messages(room_id, sent_at)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Database migrations will be added here before changing the schema version.
    }

    fun save(message: ChatMessage) {
        val values = ContentValues().apply {
            put("id", message.id)
            put("room_id", message.roomId)
            put("sender_id", message.senderId)
            put("sender_name", message.senderName)
            put("body", message.text)
            put("sent_at", message.sentAt)
            put("is_mine", if (message.isMine) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("messages", null, values, SQLiteDatabase.CONFLICT_IGNORE)
        writableDatabase.execSQL(
            "DELETE FROM messages WHERE room_id = ? AND id NOT IN (SELECT id FROM messages WHERE room_id = ? ORDER BY sent_at DESC LIMIT 500)",
            arrayOf(message.roomId, message.roomId)
        )
    }

    fun load(roomId: String): List<ChatMessage> {
        val result = ArrayList<ChatMessage>()
        readableDatabase.query(
            "messages",
            arrayOf("id", "room_id", "sender_id", "sender_name", "body", "sent_at", "is_mine"),
            "room_id = ?",
            arrayOf(roomId),
            null,
            null,
            "sent_at ASC",
            "500"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += ChatMessage(
                    id = cursor.getString(0),
                    roomId = cursor.getString(1),
                    senderId = cursor.getString(2),
                    senderName = cursor.getString(3),
                    text = cursor.getString(4),
                    sentAt = cursor.getLong(5),
                    isMine = cursor.getInt(6) == 1
                )
            }
        }
        return result
    }

    companion object {
        private const val DATABASE_NAME = "kovan_messages.db"
        private const val DATABASE_VERSION = 1
    }
}
