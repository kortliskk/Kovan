package com.kortliskk.kovan.network

import com.kortliskk.kovan.model.ChatMessage
import com.kortliskk.kovan.security.RoomCipher
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Foreground-only LAN transport. Devices must be on the same Wi-Fi/LAN.
 * Routers with client isolation may block device-to-device broadcast traffic.
 */
class LanChatEngine(private val listener: Listener) {

    interface Listener {
        fun onMessage(message: ChatMessage)
        fun onStatus(message: String)
        fun onPeerCount(count: Int)
        fun onError(message: String)
    }

    @Volatile private var running = false
    @Volatile private var receiverSocket: DatagramSocket? = null
    private var receiverThread: Thread? = null
    private var heartbeatThread: Thread? = null
    private lateinit var cipher: RoomCipher
    private lateinit var roomId: String
    private lateinit var displayName: String
    private val localDeviceId = UUID.randomUUID().toString()
    private val peers = ConcurrentHashMap<String, Long>()
    private val seenIds = LinkedHashSet<String>()
    private val seenLock = Any()

    @Synchronized
    fun start(name: String, roomName: String, password: String) {
        stop()
        displayName = name.trim()
        roomId = RoomCipher.roomHash(roomName)
        cipher = RoomCipher(roomName, password)
        running = true
        peers.clear()
        synchronized(seenLock) { seenIds.clear() }

        receiverThread = Thread({ receiveLoop() }, "KOVAN-LAN-Receiver").apply {
            isDaemon = true
            start()
        }
        heartbeatThread = Thread({ heartbeatLoop() }, "KOVAN-LAN-Heartbeat").apply {
            isDaemon = true
            start()
        }
        listener.onStatus("Yerel ağ odası başlatıldı")
    }

    fun sendMessage(text: String): ChatMessage {
        check(running) { "Önce bir odaya bağlanmalısın." }
        val cleanText = text.trim()
        require(cleanText.isNotEmpty()) { "Mesaj boş olamaz." }
        require(cleanText.length <= MAX_MESSAGE_LENGTH) { "Mesaj en fazla $MAX_MESSAGE_LENGTH karakter olabilir." }

        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val payload = JSONObject()
            .put("kind", "message")
            .put("senderId", localDeviceId)
            .put("senderName", displayName)
            .put("text", cleanText)
            .put("sentAt", now)
        sendEncrypted(id, payload)
        remember(id)
        return ChatMessage(
            id = id,
            roomId = roomId,
            senderId = localDeviceId,
            senderName = displayName,
            text = cleanText,
            sentAt = now,
            isMine = true
        )
    }

    @Synchronized
    fun stop() {
        running = false
        receiverSocket?.close()
        receiverSocket = null
        heartbeatThread?.interrupt()
        receiverThread?.interrupt()
        heartbeatThread = null
        receiverThread = null
        peers.clear()
        listener.onPeerCount(0)
        listener.onStatus("Bağlı değil")
    }

    private fun receiveLoop() {
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket(null).apply {
                reuseAddress = true
                soTimeout = 1_000
                bind(InetSocketAddress(PORT))
            }
            receiverSocket = socket
            listener.onStatus("Yerel ağ dinleniyor")

            while (running) {
                try {
                    val buffer = ByteArray(MAX_PACKET_BYTES)
                    val packet = DatagramPacket(buffer, buffer.size)
                    socket.receive(packet)
                    val raw = String(packet.data, packet.offset, packet.length, Charsets.UTF_8)
                    processPacket(raw)
                } catch (_: java.net.SocketTimeoutException) {
                    expirePeers()
                } catch (e: SocketException) {
                    if (running) listener.onError("Ağ bağlantısı kesildi: ${e.message ?: "soket hatası"}")
                    break
                } catch (_: Exception) {
                    // Ignore malformed, duplicated, or unauthenticated broadcast packets.
                }
            }
        } catch (e: Exception) {
            if (running) listener.onError("Yerel ağ açılamadı: ${e.message ?: "bilinmeyen hata"}")
        } finally {
            socket?.close()
            if (receiverSocket === socket) receiverSocket = null
        }
    }

    private fun heartbeatLoop() {
        while (running) {
            try {
                val hello = JSONObject()
                    .put("kind", "hello")
                    .put("senderId", localDeviceId)
                    .put("senderName", displayName)
                    .put("sentAt", System.currentTimeMillis())
                sendEncrypted(UUID.randomUUID().toString(), hello)
                expirePeers()
                Thread.sleep(HEARTBEAT_INTERVAL_MS)
            } catch (_: InterruptedException) {
                break
            } catch (e: Exception) {
                if (running) listener.onError("Ağ paketi gönderilemedi: ${e.message ?: "hata"}")
                try {
                    Thread.sleep(HEARTBEAT_INTERVAL_MS)
                } catch (_: InterruptedException) {
                    break
                }
            }
        }
    }

    private fun sendEncrypted(id: String, payload: JSONObject) {
        val aad = "$roomId|$id"
        val encrypted = cipher.encrypt(payload.toString(), aad)
        val packetJson = JSONObject()
            .put("version", PROTOCOL_VERSION)
            .put("room", roomId)
            .put("id", id)
            .put("nonce", encrypted.nonce)
            .put("payload", encrypted.ciphertext)
        val bytes = packetJson.toString().toByteArray(Charsets.UTF_8)
        require(bytes.size <= MAX_PACKET_BYTES) { "Mesaj paketi çok büyük." }

        DatagramSocket().use { sendingSocket ->
            sendingSocket.broadcast = true
            val address = InetAddress.getByName(BROADCAST_ADDRESS)
            val packet = DatagramPacket(bytes, bytes.size, address, PORT)
            sendingSocket.send(packet)
        }
    }

    private fun processPacket(raw: String) {
        val packet = JSONObject(raw)
        if (packet.optInt("version") != PROTOCOL_VERSION) return
        if (packet.optString("room") != roomId) return
        val id = packet.optString("id")
        if (id.isBlank() || id.length > 80) return

        val plainText = cipher.decrypt(
            nonceBase64 = packet.getString("nonce"),
            ciphertextBase64 = packet.getString("payload"),
            associatedData = "$roomId|$id"
        )
        val message = JSONObject(plainText)
        val senderId = message.optString("senderId")
        if (senderId.isBlank() || senderId == localDeviceId) return
        if (!remember(id)) return

        when (message.optString("kind")) {
            "hello" -> {
                peers[senderId] = System.currentTimeMillis()
                listener.onPeerCount(peers.size)
            }
            "message" -> {
                val text = message.optString("text")
                val senderName = message.optString("senderName", "KOVAN kullanıcısı")
                val sentAt = message.optLong("sentAt", System.currentTimeMillis())
                if (text.isNotBlank() && text.length <= MAX_MESSAGE_LENGTH) {
                    peers[senderId] = System.currentTimeMillis()
                    listener.onPeerCount(peers.size)
                    listener.onMessage(
                        ChatMessage(
                            id = id,
                            roomId = roomId,
                            senderId = senderId,
                            senderName = senderName.take(24),
                            text = text,
                            sentAt = sentAt,
                            isMine = false
                        )
                    )
                }
            }
        }
    }

    private fun remember(id: String): Boolean = synchronized(seenLock) {
        if (!seenIds.add(id)) return@synchronized false
        while (seenIds.size > MAX_REMEMBERED_IDS) {
            val iterator = seenIds.iterator()
            if (iterator.hasNext()) {
                iterator.next()
                iterator.remove()
            } else break
        }
        true
    }

    private fun expirePeers() {
        val cutoff = System.currentTimeMillis() - PEER_TIMEOUT_MS
        peers.entries.removeIf { it.value < cutoff }
        listener.onPeerCount(peers.size)
    }

    companion object {
        private const val PORT = 47_821
        private const val BROADCAST_ADDRESS = "255.255.255.255"
        private const val PROTOCOL_VERSION = 1
        private const val MAX_PACKET_BYTES = 8_192
        private const val MAX_MESSAGE_LENGTH = 1_200
        private const val MAX_REMEMBERED_IDS = 600
        private const val HEARTBEAT_INTERVAL_MS = 7_000L
        private const val PEER_TIMEOUT_MS = 22_000L
    }
}
