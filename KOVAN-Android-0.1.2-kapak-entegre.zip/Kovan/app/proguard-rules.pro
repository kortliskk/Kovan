# KOVAN release shrinker rules.
