# Security policy

KOVAN 0.1.0 is an experimental local-network prototype, not a security-audited messenger.

Do not use it for highly sensitive communications. Do not publish room passwords,
private messages, or personal information in public issue reports.

For a suspected security issue, contact kortliskk@gmail.com and include only the
minimum information needed to understand the report.
